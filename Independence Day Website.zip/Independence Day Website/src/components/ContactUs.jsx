import React from "react";
import "../css/ContactUs.css";

const ContactUs = () => {
  return (
    <section id="contact">
      <div className="All">
        <div className="container">
          <div className="contact-content">
            {/* Contact Form Section */}
            <div className="contact-form-section">
              <h1>CONTACT US</h1>
              <h2>Get in Touch!</h2>

              {/* Contact Form */}
              <form>
                <div className="form-group">
                  <label htmlFor="name">Name</label>
                  <input type="text" id="name" name="name" />
                </div>

                <div className="form-group">
                  <label htmlFor="email">Email*</label>
                  <input type="email" id="email" name="email" required />
                </div>

                <div className="form-group">
                  <label htmlFor="message">Message</label>
                  <textarea id="message" name="message" rows="6"></textarea>
                </div>

                <div className="form-attachments">
                  <a href="#" className="attach-files">
                    <i className="fas fa-paperclip"></i> Attach Files
                  </a>
                  <span>Attachments (0)</span>
                </div>

                <button type="submit" className="send-button">
                  Send
                </button>
              </form>

              <p className="recaptcha-notice">
                This site is protected by reCAPTCHA and the Google Privacy
                Policy and Terms of Service apply.
              </p>
            </div>

            {/* Contact Info Section */}
            <div className="contact-info-section">
              <h2>WE'D LOVE TO HEAR FROM YOU!</h2>
              <p>
                Join hands in celebrating 14 August — share your thoughts,
                stories, or patriotic messages with us.
              </p>

              <a href="https://wa.me/923415878569" className="whatsapp-button">
                <i className="fab fa-whatsapp"></i> WhatsApp
              </a>

              <div className="travel-hunt-info">
                <h2>A.R.C.H.E.R Insight</h2>
                <p>
                  Your voice matters — connect with us to honor Pakistan’s
                  journey of freedom.
                </p>
                <p>WhatsApp: +92 341 5878569</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactUs;
