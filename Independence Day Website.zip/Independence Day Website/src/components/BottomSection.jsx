import React from "react";
import "../css/BottomSection.css";

import logoIcon from "../assets/images/78th-year-pakistans.png";
import locationIcon from "../assets/images/location_icon_footer.svg";
import phoneIcon from "../assets/images/phone-white.svg";
import emailIcon from "../assets/images/ic_round-email.svg";

const BottomSection = () => {
  return (
    <div id="contact" className="footer-bg">
      <div className="footer-container">
        {/* Logo and Address Section */}
        <div className="footer-section">
          <div className="logo-container">
            <div className="footer-logo">
              <img src={logoIcon} alt="A.R.C.H.E.R Insight Logo" />
            </div>
          </div>
          <div className="address-info">
            <img
              src={locationIcon}
              alt="Location Icon"
              className="address-icon"
            />
            <p>Islamabad, Pakistan</p>
          </div>
        </div>

        {/* About Section */}
        <div className="footer-section">
          <h3 className="footer-text-light section-title">About</h3>
          <ul className="list-items">
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Our Mission
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Independence Stories
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Community Projects
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Events
              </a>
            </li>
          </ul>
        </div>

        {/* Quick Links Section */}
        <div className="footer-section">
          <h3 className="footer-text-light section-title">Quick Links</h3>
          <ul className="list-items">
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Azadi Gallery
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                National Landmarks
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Freedom Leaders
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Get Involved
              </a>
            </li>
          </ul>
        </div>

        {/* Join Us Section */}
        <div className="footer-section">
          <h3 className="footer-text-light section-title">Join Us</h3>
          <ul className="list-items">
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                As a Volunteer
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                As a Contributor
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Share Your Story
              </a>
            </li>
            <li>
              <a href="#" className="footer-link footer-text-lighter">
                Sponsor an Event
              </a>
            </li>
          </ul>
        </div>

        {/* Contact Us Section */}
        <div className="footer-section">
          <h3 className="footer-text-light section-title">Contact Us</h3>
          <ul className="list-items">
            <li className="contact-item">
              <img src={phoneIcon} alt="Phone Icon" className="contact-icon" />
              <span className="footer-text-lighter">0341-5878569</span>
            </li>
            <li className="contact-item">
              <img src={emailIcon} alt="Email Icon" className="contact-icon" />
              <span className="footer-text-lighter">
                AbdulBasit.Alpha25@gmail.com
              </span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default BottomSection;
