import "../css/Gallery.css";

import React, { useState, useEffect } from "react";
import flagImage from "../assets/images/pakistan-flag.jpg";
import minarImage from "../assets/images/minar-e-pakistan.jpg";
import culturalImage from "../assets/images/Pakistan-Culture.jpg"; // same image for testing
import monumentImage from "../assets/images/monumentImage.jpg"; // same image for testing
import fireworksImage from "../assets/images/fireworksImage.jpg"; // same image for testing
import paradeImage from "../assets/images/Independence-Day-parade.jpg"; // same image for testing

const Gallery = () => {
  const galleryItems = [
    {
      img: flagImage,
      title: "Pakistani Flag",
      description: "Symbol of freedom and unity.",
    },
    {
      img: minarImage,
      title: "Minar-e-Pakistan",
      description: "Iconic monument representing independence.",
    },
    {
      img: culturalImage,
      title: "Cultural Heritage",
      description: "Celebrating Pakistan's traditions and culture.",
    },
    {
      img: monumentImage,
      title: "Historical Monuments",
      description: "Showcasing Pakistan's rich history.",
    },
    {
      img: fireworksImage,
      title: "Festive Fireworks",
      description: "Lighting up the night with celebration.",
    },
    {
      img: paradeImage,
      title: "Independence Parade",
      description: "Celebrating with people nationwide.",
    },
  ];

  const [startIndex, setStartIndex] = useState(0);
  const itemsPerPage = 3;

  const nextSlide = () => {
    setStartIndex((prevIndex) =>
      prevIndex + itemsPerPage >= galleryItems.length
        ? 0
        : prevIndex + itemsPerPage
    );
  };

  const prevSlide = () => {
    setStartIndex((prevIndex) =>
      prevIndex - itemsPerPage < 0
        ? galleryItems.length - itemsPerPage
        : prevIndex - itemsPerPage
    );
  };

  // Auto slide every 3 seconds — fixed dependency issue
  useEffect(() => {
    const interval = setInterval(() => {
      setStartIndex((prevIndex) =>
        prevIndex + itemsPerPage >= galleryItems.length
          ? 0
          : prevIndex + itemsPerPage
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Get current visible items
  const visibleItems = galleryItems.slice(
    startIndex,
    startIndex + itemsPerPage
  );

  // Wrap around if fewer items at end
  if (visibleItems.length < itemsPerPage) {
    visibleItems.push(
      ...galleryItems.slice(0, itemsPerPage - visibleItems.length)
    );
  }

  return (
    <section id="Gallery" className="Gallery">
      <h2>Celebrate Pakistan Independence Day</h2>

      <div className="slider-container">
        <button className="slider-btn prev-btn" onClick={prevSlide}>
          &#10094;
        </button>

        <div className="slider-frame">
          {visibleItems.map((item, index) => (
            <div key={index} className="slider-card">
              <img src={item.img} alt={item.title} className="gallery-img" />
              <div className="card-content">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>

        <button className="slider-btn next-btn" onClick={nextSlide}>
          &#10095;
        </button>
      </div>

      <div className="dots-container">
        {Array.from({
          length: Math.ceil(galleryItems.length / itemsPerPage),
        }).map((_, idx) => (
          <span
            key={idx}
            className={`dot ${
              startIndex / itemsPerPage === idx ? "active" : ""
            }`}
            onClick={() => setStartIndex(idx * itemsPerPage)}
          ></span>
        ))}
      </div>
    </section>
  );
};

export default Gallery;
