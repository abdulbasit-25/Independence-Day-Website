import React from "react";
import { useInView } from "react-intersection-observer";
import "../css/HistoryPage.css";

// Image components
const QuaidImage = () => (
  <img
    src={require("../assets/images/Quaid-e-Azam Muhammad Ali Jinnah.jpg")}
    alt="Quaid-e-Azam"
    className="timeline-img"
  />
);

const FreedomImage = () => (
  <img
    src={require("../assets/images/freedom-fighters.png")}
    alt="Freedom Movement"
    className="timeline-img"
  />
);

const ResolutionImage = () => (
  <img
    src={require("../assets/images/minar-e-pakistan.png")}
    alt="Lahore Resolution"
    className="timeline-img"
  />
);

const IndependenceImage = () => (
  <img
    src={require("../assets/images/pakistan-flag.jpg")}
    alt="Independence Day"
    className="timeline-img"
  />
);

// Data array
const historyData = [
  {
    title: "Vision of Quaid-e-Azam",
    date: "1930s",
    description:
      "Muhammad Ali Jinnah envisioned a homeland where Muslims could practice their beliefs freely, with dignity and equality.",
    ImageComponent: QuaidImage,
  },
  {
    title: "Growing Nationalism",
    date: "1935",
    description:
      "The Government of India Act 1935 laid the groundwork for limited self-rule and further fueled the demand for independence.",
    ImageComponent: FreedomImage,
  },
  {
    title: "Lahore Resolution",
    date: "23 March 1940",
    description:
      "The historic Lahore Resolution formally demanded a separate nation for Muslims — what would later become Pakistan.",
    ImageComponent: ResolutionImage,
  },
  {
    title: "Civil Disobedience",
    date: "1942",
    description:
      "Mass movements and protests began challenging British rule directly, accelerating the push for independence.",
    ImageComponent: FreedomImage,
  },
  {
    title: "Negotiations & Struggles",
    date: "1946",
    description:
      "Despite negotiations and conflicts, Muslim leaders stayed firm on the idea of a sovereign state.",
    ImageComponent: QuaidImage,
  },
  {
    title: "Independence Achieved",
    date: "14 August 1947",
    description:
      "After years of struggle and sacrifices, Pakistan emerged as an independent nation.",
    ImageComponent: IndependenceImage,
  },
  {
    title: "Early Nation Building",
    date: "1948–1950",
    description:
      "Pakistan focused on rebuilding, resettling migrants, and establishing its new identity.",
    ImageComponent: IndependenceImage,
  },
  {
    title: "Legacy of the Founders",
    date: "1950s",
    description:
      "The vision of Quaid-e-Azam continued to shape the values and direction of the young nation.",
    ImageComponent: QuaidImage,
  },
];

// New component for each timeline row, with intersection observer hook
const TimelineRow = ({ title, description, ImageComponent, date, isEven }) => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.3,
  });

  return (
    <section id="history">
      <div ref={ref} className={`timeline-row ${inView ? "animate" : ""}`}>
        <div className="timeline-marker">
          <div className="timeline-dot" />
          <div className="timeline-date">{date}</div>
        </div>

        <div className="timeline-content-left">
          {isEven ? (
            <div className="timeline-text">
              <h2>{title}</h2>
              <p>{description}</p>
            </div>
          ) : (
            <ImageComponent />
          )}
        </div>

        <div className="timeline-content-right">
          {isEven ? (
            <ImageComponent />
          ) : (
            <div className="timeline-text">
              <h2>{title}</h2>
              <p>{description}</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

const HistoryPage = () => {
  return (
    <main className="timeline-container">
      <h1 className="timeline-title">🇵🇰 Pakistan's Path to Independence</h1>
      <section className="timeline">
        {historyData.map(
          ({ title, description, ImageComponent, date }, index) => (
            <TimelineRow
              key={index}
              title={title}
              description={description}
              ImageComponent={ImageComponent}
              date={date}
              isEven={index % 2 === 0}
            />
          )
        )}
      </section>
    </main>
  );
};

export default HistoryPage;
