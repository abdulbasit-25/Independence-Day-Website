import React, { useEffect, useState } from "react";
import "../css/Events.css";

import FlagImage from "../assets/images/Independence-Day-flaghosting.jpg";
import ParadeImage from "../assets/images/Independence-Day-parade.jpg";
import FireworksImage from "../assets/images/Independence-Day-fireworks.jpg";
import ConcertImage from "../assets/images/Independence-Day-concert.jpg";

import ParadeRehearsalImage from "../assets/images/Independence-Day-ParadeRehearsal.jpg";
import SoundCheckImage from "../assets/images/Independence-Day-SoundCheck.jpg";
import CommunityPotluckImage from "../assets/images/Independence-Day-CommunityPotluck.jpg";
import ArtExhibitionImage from "../assets/images/Independence-Day-ArtExhibition.jpg";

const eventsData = [
  {
    id: 1,
    title: "Flag Hoisting Ceremony",
    date: "2025-08-14T08:00:00+05:00",
    venue: "Parade Ground",
    category: "Public",
    image: FlagImage,
    description: "A grand ceremony with national anthem and flag hoisting.",
  },
  {
    id: 2,
    title: "Military Parade",
    date: "2025-08-14T14:00:00+05:00",
    venue: "Parade Ground",
    category: "Official",
    image: ParadeImage,
    description:
      "A grand military parade showcasing the strength and discipline of the armed forces.",
  },
  {
    id: 3,
    title: "Fireworks Night",
    date: "2025-08-13T23:59:00+05:00",
    venue: "Giga Mall",
    category: "Public",
    image: FireworksImage,
    description: "An unforgettable fireworks show lighting up the sky.",
  },
  {
    id: 4,
    title: "Independence Day Concert",
    date: "2025-08-13T20:00:00+05:00",
    venue: "Ayub Park",
    category: "Cultural",
    image: ConcertImage,
    description: "Live music concert featuring top Pakistani artists.",
  },

  // Past events (already ended)
  {
    id: 5,
    title: "Flag Hoisting Rehearsal",
    date: "2025-08-12T09:00:00+05:00",
    venue: "Parade Ground",
    category: "Public",
    image: ParadeRehearsalImage,
    description: "Rehearsal session for the upcoming flag hoisting ceremony.",
  },
  {
    id: 6,
    title: "Sound Check for Concert",
    date: "2025-08-12T16:00:00+05:00",
    venue: "Ayub Park",
    category: "Cultural",
    image: SoundCheckImage,
    description: "Sound check and setup for the Independence Day concert.",
  },

  // Upcoming future events
  {
    id: 7,
    title: "Community Potluck",
    date: "2025-08-15T12:00:00+05:00",
    venue: "Community Center",
    category: "Public",
    image: CommunityPotluckImage,
    description:
      "A potluck lunch where community members share traditional dishes.",
  },
  {
    id: 8,
    title: "Art & Craft Exhibition",
    date: "2025-08-16T10:00:00+05:00",
    venue: "City Museum",
    category: "Cultural",
    image: ArtExhibitionImage,
    description: "Exhibition showcasing local artists and traditional crafts.",
  },
];

// Format date: DD Month YYYY
const formatDate = (dateStr) =>
  new Date(dateStr).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

// Format time in 12-hour format with AM/PM in Asia/Karachi timezone
const formatTime = (dateStr) =>
  new Date(dateStr).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
    timeZone: "Asia/Karachi",
  });

// Get YYYY-MM-DD date string in Asia/Karachi timezone for comparison/filtering
const getDateStr = (date) =>
  new Date(date.toLocaleString("en-US", { timeZone: "Asia/Karachi" }))
    .toISOString()
    .slice(0, 10);

const Events = () => {
  const [now, setNow] = useState(new Date());
  const [showPastEvents, setShowPastEvents] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      const timeInKarachi = new Date(
        new Date().toLocaleString("en-US", { timeZone: "Asia/Karachi" })
      );
      setNow(timeInKarachi);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const todayStr = getDateStr(now);
  const tomorrowDate = new Date(now);
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrowStr = getDateStr(tomorrowDate);

  // Filter events by exact date string in Asia/Karachi timezone
  const todayEvents = eventsData.filter(
    (e) => e.date.slice(0, 10) === todayStr
  );
  const tomorrowEvents = eventsData.filter(
    (e) => e.date.slice(0, 10) === tomorrowStr
  );

  // Past events: date before today
  const pastEvents = eventsData.filter((e) => e.date.slice(0, 10) < todayStr);

  // Placeholder image URL (replace with your own or use a local one)
  const placeholderImage = "https://via.placeholder.com/400x180?text=No+Image";

  return (
    <section id="Events">
      <div className="events-modern">
        <header className="hero">
          <h1>🇵🇰 Independence Events</h1>
          <p className="live-date-time">
            Islamabad Time:{" "}
            <time dateTime={now.toISOString()}>
              {now.toLocaleDateString("en-GB", {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric",
              })}{" "}
              -{" "}
              {now.toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                hour12: true,
                timeZone: "Asia/Karachi",
              })}
            </time>
          </p>
        </header>

        <section className="events-section">
          <h2>Today's Events ({todayStr})</h2>
          {todayEvents.length === 0 && <p>No events scheduled for today.</p>}
          <div className="events-grid">
            {todayEvents.map((event) => (
              <div className="event-card" key={event.id}>
                <div className="event-image-wrapper">
                  <img
                    src={event.image || placeholderImage}
                    alt={event.title}
                    className="event-image"
                  />
                  <span
                    className={`event-category category-${event.category.toLowerCase()}`}
                    aria-label={`Category: ${event.category}`}
                  >
                    {event.category}
                  </span>
                </div>
                <div className="event-card-content">
                  <h3 className="event-card-title">{event.title}</h3>
                  <p className="event-time">
                    <time dateTime={event.date}>
                      {formatDate(event.date)} at {formatTime(event.date)}
                    </time>
                  </p>
                  <p className="event-venue">Venue: {event.venue}</p>
                  <p className="event-card-description">{event.description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="events-section">
          <h2>Tomorrow's Events ({tomorrowStr})</h2>
          {tomorrowEvents.length === 0 && (
            <p>No events scheduled for tomorrow.</p>
          )}
          <div className="events-grid">
            {tomorrowEvents.map((event) => (
              <div className="event-card" key={event.id}>
                <div className="event-image-wrapper">
                  <img
                    src={event.image || placeholderImage}
                    alt={event.title}
                    className="event-image"
                  />
                  <span
                    className={`event-category category-${event.category.toLowerCase()}`}
                    aria-label={`Category: ${event.category}`}
                  >
                    {event.category}
                  </span>
                </div>
                <div className="event-card-content">
                  <h3 className="event-card-title">{event.title}</h3>
                  <p className="event-time">
                    <time dateTime={event.date}>
                      {formatDate(event.date)} at {formatTime(event.date)}
                    </time>
                  </p>
                  <p className="event-venue">Venue: {event.venue}</p>
                  <p className="event-card-description">{event.description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="events-section">
          <h2>
            Past Events{" "}
            <button
              onClick={() => setShowPastEvents(!showPastEvents)}
              className="toggle-past-events-btn"
              aria-expanded={showPastEvents}
              aria-controls="past-events-list"
            >
              {showPastEvents ? "Hide" : "Show"}
            </button>
          </h2>
          {showPastEvents && (
            <>
              {pastEvents.length === 0 && <p>No past events found.</p>}
              <div className="events-grid" id="past-events-list">
                {pastEvents.map((event) => (
                  <div className="event-card" key={event.id}>
                    <div className="event-image-wrapper">
                      <img
                        src={event.image || placeholderImage}
                        alt={event.title}
                        className="event-image"
                      />
                      <span
                        className={`event-category category-${event.category.toLowerCase()}`}
                        aria-label={`Category: ${event.category}`}
                      >
                        {event.category}
                      </span>
                    </div>
                    <div className="event-card-content">
                      <h3 className="event-card-title">{event.title}</h3>
                      <p className="event-time">
                        <time dateTime={event.date}>
                          {formatDate(event.date)} at {formatTime(event.date)}
                        </time>
                      </p>
                      <p className="event-venue">Venue: {event.venue}</p>
                      <p className="event-card-description">
                        {event.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </section>
      </div>
    </section>
  );
};

export default Events;
