import React from "react";
import "../css/Footer.css";

import linkedinIcon from "../assets/images/linkedin.png";
import youtubeIcon from "../assets/images/youtube.png";
import instagramIcon from "../assets/images/Instagram.png";
import facebookIcon from "../assets/images/Facebook.png";

const Footer = () => {
  return (
    <footer className="below-footer">
      <div className="footer-container">
        <div className="footer-copyright">
          <p>Copyright © 2025. Engreez. All rights reserved.</p>
        </div>

        <div className="footer-social">
          <a
            href="https://linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img src={linkedinIcon} alt="LinkedIn" className="icon-inside" />
          </a>
          <a
            href="https://youtube.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img src={youtubeIcon} alt="YouTube" className="icon-inside" />
          </a>
          <a
            href="https://instagram.com/__abdul.basitt"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img src={instagramIcon} alt="Instagram" className="icon-inside" />
          </a>
          <a
            href="https://facebook.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img src={facebookIcon} alt="Facebook" className="icon-inside" />
          </a>
        </div>

        <div className="footer-links">
          <a href="#">FAQs</a> | <a href="#">Payment Policy</a> |{" "}
          <a href="#">Terms & Conditions</a> | <a href="#">Privacy Policy</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
