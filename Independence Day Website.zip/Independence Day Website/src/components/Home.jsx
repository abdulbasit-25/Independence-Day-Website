import "../css/Home.css";
import React from "react";
import minar from "../assets/images/minar-e-pakistan.png"; // update path if needed

const MainSection = () => {
  return (
    <section className="main-section">
      <div className="left">
        <h1 className="title">Happy Independence Day</h1>
        <p className="subtitle">
          Celebrating the spirit of freedom, unity, and pride for our beloved
          Pakistan. May our flag always fly high.
        </p>
        <div className="buttons">
          <button className="btn-primary">Learn More</button>
          <button className="btn-secondary">Join the Celebration</button>
        </div>
      </div>
      <div className="right">
        <img src={minar} alt="Minar-e-Pakistan" className="minar-img" />
      </div>
    </section>
  );
};

export default MainSection;
