import React from "react";
import "../css/TributePage.css";

// Images
import Quaid from "../assets/images/Quaid-e-Azam Muhammad Ali Jinnah.jpg";
import Iqbal from "../assets/images/Allama Iqbal.jpg"; // Assuming you have this image

function TributePage() {
  return (
    <section id="Tributes">
      <div className="tribute-page">
        <header className="tribute-header">
          <h1>Tribute to National Heroes</h1>
        </header>

        {/* Quaid-e-Azam Section (Image first) */}
        <section className="hero-section">
          <div className="hero-image">
            <img
              src={Quaid}
              alt="Quaid-e-Azam Muhammad Ali Jinnah"
              className="hero-img"
            />
          </div>
          <div className="hero-text">
            <h2>Quaid-e-Azam Muhammad Ali Jinnah</h2>
            <p>
              Muhammad Ali Jinnah (1876 – 1948) was the driving force behind the
              creation of Pakistan. His unwavering dedication, sharp leadership,
              and vision for a separate homeland for Muslims shaped the destiny
              of millions. Known as "Quaid-e-Azam" (The Great Leader), he laid
              the foundation for a democratic and progressive nation.
            </p>
            <a
              href="https://en.wikipedia.org/wiki/Muhammad_Ali_Jinnah"
              target="_blank"
              rel="noopener noreferrer"
              className="learn-more-btn"
            >
              Learn More
            </a>
          </div>
        </section>

        {/* Allama Iqbal Section (Text first, Image second) */}
        <section className="hero-section reverse">
          <div className="hero-text" style={{ marginRight: "120px" }}>
            <h2>Allama Muhammad Iqbal</h2>
            <p>
              Allama Iqbal (1877 – 1938) was a philosopher, poet, and politician
              in British India who is widely regarded as the most important
              figure in the intellectual history of modern-day Pakistan. He
              inspired the vision of a separate Muslim state and is regarded as
              the spiritual father of Pakistan.
            </p>
            <a
              href="https://en.wikipedia.org/wiki/Muhammad_Iqbal"
              target="_blank"
              rel="noopener noreferrer"
              className="learn-more-btn"
            >
              Learn More
            </a>
          </div>

          <div className="hero-image" style={{ marginRight: "-100px" }}>
            <img src={Iqbal} alt="Allama Iqbal" className="hero-img" />
          </div>
        </section>
      </div>
    </section>
  );
}

export default TributePage;
