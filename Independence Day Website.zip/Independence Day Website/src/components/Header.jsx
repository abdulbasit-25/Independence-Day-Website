import React from "react";
import "../css/Header.css";
import logo from "../assets/images/78th-year-pakistans.png"; // Replace with your Independence Day logo

const Header = () => {
  return (
    <header className="header independence-header">
      <div className="container">
        {/* Logo Section */}
        <div className="logo">
          <img src={logo} alt="Pakistan Independence Day 2025 Logo" />
        </div>

        {/* Navigation Links */}
        <nav className="nav-links">
          <a href="#home">Home</a>
          <a href="#Gallery">Gallery</a>
          <a href="#history">History</a>
          <a href="#Events">Events</a>
          <a href="#Tributes">Tribute</a>
          <a href="#contact">Contact Us</a>
        </nav>

        {/* Action Buttons */}
        <div className="header-buttons">
          <button className="celebrate-btn">Celebrate Now</button>
          <button className="countdown-btn">14 August 2025</button>
        </div>
      </div>
    </header>
  );
};

export default Header;
