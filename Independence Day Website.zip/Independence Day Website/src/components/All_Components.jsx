import React from "react";
import "../css/All_Componenets.css";
import "../App.css";
import Header from "./Header";
import Home from "./Home";
import Gallery from "./Gallery";
import HistoryPage from "./HistoryPage";
import TributePage from "./TributePage";
import BottomSection from "./BottomSection";
import ContactUs from "./ContactUs";
import Events from "./Events";
import Footer from "./footer";

function All_Components() {
  return (
    <div className="App">
      <Header />
      <Home />
      <Gallery />
      <HistoryPage />
      <Events />
      <TributePage />
      <ContactUs />
      <BottomSection />
      <Footer />
    </div>
  );
}

export default All_Components;
