import React from "react";
import All_Components from "../src/components/All_Components";

function App() {
  return (
    <div className="App">
      <All_Components />
    </div>
  );
}

export default App;
